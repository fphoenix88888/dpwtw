declare module '@uiw/react-md-editor';
